var controller={
    allCellsFired:function(){
      return model.cells.every(function(c){
        return c.fired;
      });
    },
    gameFinished: function(){
      return (model.ships.every(function(ship){return ship.sunken;}) || this.allCellsFired());
    },
    fire:function(element){
      // envista a posição da tacada com base em Row+Column.ex: "B1"
      var firePosition = element.getAttribute("data-row")+element.getAttribute("data-cell");
      var shipHitted;
      
      model.ships.forEach(function(ship){
        if(ship.location.includes(firePosition))
          shipHitted = ship;
      });
      
      if(shipHitted != null){
          var idx = shipHitted.location.indexOf(firePosition);
          shipHitted.state[idx] = 0;
          shipHitted.sunken = !shipHitted.state.includes(1);
      }
      
      model.cells.find(function(c){return c.idx == firePosition;}).fired = true;
      view.update();
      
      if(this.gameFinished()){
        view.gameFinished();
        this.restart();
      }
    },
    restart:function(){
      //reiniciar
      model.ships=[];
      model.generateShips();
      model.cells=[];
      model.generateCells();
      //reiniciar a visão 
      view.update();
    }
  }
  
  var model = {
    boardSize:7,
    numberOfShips:3,
    shipsLength:3,
    cells:[],
    ships:[],
    generateCells:function(){
    for(var i = 0; i < model.boardSize; i++){
      for(var j = 0; j < model.boardSize; j++){
        this.cells.push({

         idx:String.fromCharCode(65 + j)+parseInt(i+1),
         row:String.fromCharCode(65 + j),
         column:parseInt(i+1),
         fired:false,
        });
      }
    }
  },
    generateShips:function(){
      while(this.ships.length < model.numberOfShips){
        var ship = this.genShip();
  
        if(!model.badPosition(ship)){
          this.ships.push(ship);
        }
      }
    },
    genShip:function(){
        var pos = Math.floor(Math.random() * 2);
        var row = Math.floor(Math.random() * (model.boardSize - model.shipsLength))+1; 
        var col = Math.floor(Math.random() * (model.boardSize - model.shipsLength))+1;
        
        switch(pos) {
          case 0 : //posição horizontal 
            var loc=[]; 
            for(var j =0 ; j < model.shipsLength ; j++){
                loc.push(String.fromCharCode(row+65) + (parseInt(j)+col));
             }
             break;
           
          case 1 : //posição vertica
              var loc=[];
              for(var j =0 ; j < model.shipsLength ; j++){
                loc.push(String.fromCharCode(65+parseInt(j))+col);
              }
              break;
           
          default:
              break;
         }
        
        return { 
          location:loc,
          state:[1,1,1],
          sunken:false };
         },
    badPosition:function(ship){
      return model.ships.some(function(s){
        return model.shipsCollition(s,ship);
      });
    },
    shipsCollition:function(s1,s2){
      for( var i=0 ; i < s1.location.length ; i++ ){
        if(s2.location.includes( s1.location[i] ))
          return true;
      }
    }
  }
   
  
  var view = {
    drawBoard:function(){
      var board = document.getElementById("board");
      var cellCounter = 0;
      
      var row = document.createElement("div");
      row.setAttribute("class", "row");
  
      for(var i = 0; i < model.cells.length; i++){
        var cell = document.createElement("div");
        cell.setAttribute("class", "cell");
        cell.setAttribute("id", model.cells[i].idx);
        cell.setAttribute("data-row", model.cells[i].row);
        cell.setAttribute("data-cell", model.cells[i].column);
        row.appendChild(cell);
        cellCounter++;
  
        if(cellCounter % model.boardSize == 0){
          board.appendChild(row);
          var row = document.createElement("div");
          row.setAttribute("class", "row");
        }
      }
    }, 
    update:function(){
      model.cells.map(function(cell){
        if(cell.fired){
          var shipHitted = model.ships.find(function(s){
             return s.location.includes(cell.idx);
            });
          if(shipHitted){
            document.getElementById(cell.idx).classList.add("hit");
          }else{
            document.getElementById(cell.idx).classList.add("miss");
          }
        }else{
          document.getElementById(cell.idx).classList="cell";
        }
      });
    },
    fire:function(element){
      controller.fire(element);
    },
    gameFinished:function(){
      alert("FIM DE JOGO!!!");
    }
  }
  
  function initGame(){
    model.generateCells();
    model.generateShips();
    view.drawBoard();
    view.update();
    defineCellEvent();
  }
  
  function defineCellEvent(){
    var cells = document.getElementsByClassName("cell");
    
    for(var i = 0; i < cells.length ; i++){
      cells[i].addEventListener("click", function(e){
        view.fire(e.target);
      });  
    }
  } 
  
  window.onload = initGame;
  
  