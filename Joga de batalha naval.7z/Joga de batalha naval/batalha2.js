var canvas = document.querySelector("#tabuleiro2")

var pincel = canvas.getContext("2d")

function desenhaQuadrado() {

}


function desenhaNavio(navio) {

}


